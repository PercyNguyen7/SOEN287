Vinh Tuan Dat Nguyen - 4018 0660
Assignment 2

All assignment files are found in the public folder.

I used Flowbite components for the Aside, the Footer and the Header component.
https://flowbite.com/docs/getting-started/introduction/

Image credits can be found inside a txt file of public/q7/imgs folder