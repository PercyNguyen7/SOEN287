/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./public/q7/*.{html,js}"],
  theme: {
    extend: {},
  },
  plugins: [],
};
