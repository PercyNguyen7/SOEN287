Vinh Tuan Dat Nguyen - 4018 0660
Assignment 1

All assignment files are found in the public folder.
As I already knew vanilla CSS, I wanted to explore Tailwind CSS, hence the Node js files you find here!

I used Flowbite components for the Aside, the Footer and the Header component.
https://flowbite.com/docs/getting-started/introduction/

Image/Code credits can be found inside a txt file of public/q8/img folder